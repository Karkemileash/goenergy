import React from 'react'
import { Link } from 'react-router-dom';
import { BsFacebook, BsInstagram, BsTwitter, BsYoutube, BsLinkedin } from 'react-icons/bs';
import { HiOutlineMail } from 'react-icons/hi'

const Footer = () => {
    const year = new Date().getFullYear();

    return (
        <div className=''>
            <div className=' bg-gray-800 text-white p-3 flex   md:flex-row md:gap-[10rem] justify-center  flex-col'>

                {/*about us*/}

                <div className='grid grid-cols pt-3 leading-8'>
                    <h1 className=' text-xl p  pb-3' > ABOUT GO SOLAR</h1>

                    <Link to="/aboutus" onClick={() => window.scroll(0, 0)}> About us</Link>
                    <Link to="/contactus" onClick={() => window.scroll(0, 0)}> Contact us</Link>

                    <Link to="/homeservice " onClick={() => window.scroll(0, 0)}> Home service</Link>


                </div>

                {/*product*/}

                <div className='grid grid-cols pt-3 leading-8 '>
                    <h1 className=' text-xl pb-3' onClick={() => window.scroll(0, 0)}> PRODUCTS</h1>
                    <Link to="/product/inverter" onClick={() => window.scroll(0, 0)}> Inverters</Link>
                    <Link to="/product/battery" onClick={() => window.scroll(0, 0)}> Batteries</Link>


                    <Link to="/product/solar" onClick={() => window.scroll(0, 0)}> Solar Pannel</Link>


                </div>
                {/*quicklinks*/}

                <div className='grid grid-cols pt-3  leading-8'>
                    <h1 className=' text-xl pb-3'> QUICKLINKS</h1>

                    <Link to="/support/Inquiry" onClick={() => window.scroll(0, 0)}> Customer Inquiry</Link>
                    <Link to="/support/Feedback" onClick={() => window.scroll(0, 0)}> Feedback and Complaint</Link>
                    <Link to="/terms" onClick={() => window.scroll(0, 0)}> Offer Terms And Conditions</Link>
                    <Link to="/Corporate Clients" onClick={() => window.scroll(0, 0)}> Corporate Clients</Link>

                </div>
                <div>
                    {/*Socil links*/}

                    <h1 className='font-bold text-xl  pt-4'> Social </h1>
                    <div className='flex gap-3 pt-'>

                        <a href='https://www.facebook.com/goenergynepal/'>   <BsFacebook size={20} />  </a>
                        <a href=' '>  <BsInstagram size={20} /> </a>
                        <a href=''> <BsTwitter size={20} />  </a>
                        <a href=''>  < BsYoutube size={20} /> </a>
                        <a href=''>  < BsLinkedin size={20} /> </a>  <br></br>
            

                    </div>

                    <div className='flex  pt-3'>
                    <a href='tel:980-1053774'><span className='flex gap-2 items-center'> < HiOutlineMail size={25}/>
                    info@goenergy.com.np </span> </a>
                     {/*   <span className='flex gap-2 items-center'> <RiServiceFill size={25}/> SERVICE : 98010881**</span> */}
                    </div>
                    <h1 className='mt-2'>   Copyright© {year} Go Energy</h1>

                </div>
            </div>


        </div>
    )
}

export default Footer
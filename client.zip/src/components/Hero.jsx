import React from 'react'

const Hero = ({title, desc}) => {
    return (
        <div className=' bg-[#2670B9] md:px-10 py-20'>
            <div className=' p-4 text-white'>
                <h1 className='text-2xl font-bold  text-[#FAB005]'>{title}</h1>
                <p className=' h-auto mt-2'>{desc}</p>
            </div>
        </div>
    )
}

export default Hero
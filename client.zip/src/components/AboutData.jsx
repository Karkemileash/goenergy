import inverter from '../images/inverter.jpeg'
import battery from '../images/battery.jpg'
import solar from '../images/solarr.jpg'
import one from '../images/one.png'
import two from '../images/two.png'
import three from '../images/three.png'
import four from '../images/four.png'
import vrla from '../images/vrla battery.jpg';
import lithium from '../images/lithium.jpg'
import automobile from '../images/automobile.png'
import riksha from '../images/eriksha.png'
import solarr from '../images/solar battery.png'
import wheel from '../images/wheel.jpg'
import tube from '../images/tubrrr.png'

export const items = [
    {
        name: "Inverters",
        content: "Luminous world-class Home Ups Inverters offers high technology features and are specially designed to run sensitive and heavy load household appliances as well as industrial appliances. With the built in innovative and advance technology Luminous Home Ups helps users meet their power needs across all residential and commercial segments. Luminous Home Ups Inverters provides the users best Power Back Up Solutions and right value for money.",
        image: inverter,
        link:"inverter",

    },
    {
        name: "VRLA battery",
        content: "VRLA (Valve-Regulated Lead-Acid) batteries are sealed, rechargeable batteries commonly used for backup power and in telecom equipment. They have a pressure valve to regulate internal pressure and prevent gas release. VRLA batteries are maintenance-free and have a longer life span compared to other lead-acid batteries.",
        image:vrla,
        flag: "left",
        link:"battery"
    },
    
    {
        name: "lithium battery",
        content: "Lithium batteries are rechargeable batteries that use lithium ions as the primary charge carrier. They are lightweight, have a high energy density, and a longer cycle life compared to traditional batteries. Lithium batteries are commonly used in consumer electronics, electric vehicles, and renewable energy systems. They are also known for their stability and safety, making them an attractive choice for various applications.",
        image:lithium,
        flag: "",
        link:"battery"
    },
    {
        name: "Solar battery ",
        content: "Solar batteries are rechargeable batteries that store energy generated from solar panels for use when the sun is not shining. They help to ensure a consistent and reliable source of power, even during power outages or at night. Solar batteries come in various chemistries including lead-acid, lithium-ion, and nickel-cadmium. The choice of battery depends on the specific needs of the system and the desired trade-off between cost, performance, and life span.",
        image:solarr,
        flag: "left",
        link:"battery"
    },
    {
        name: "Automative battery ",
        content: "Automotive batteries are rechargeable batteries that provide electrical energy to start a vehicle's engine and power its electrical system. They are typically lead-acid batteries and must be able to provide large bursts of power to turn the engine, while also delivering a steady amount of power to run the vehicle's electrical systems. Automotive batteries come in various sizes and capacities to match the specific requirements of different vehicle models. They must be able to perform in harsh environments and provide reliable starting power, even in extreme temperatures.",
        image:automobile,
        flag: "",
        link:"battery"
    },
    {
        name: "Two wheelers battery ",
        content: "Two-wheeler batteries are rechargeable batteries specifically designed for use in motorcycles and scooters. They provide electrical power to start the engine and run the electrical systems of the vehicle. Two-wheeler batteries are typically lead-acid batteries and come in various sizes to match the specific requirements of different two-wheeler models. ",
        image:  wheel,
        flag: "left",
        link:"battery"
    },
    {
        name: "E-Rickshaw battery ",
        content: "E-Rickshaw batteries are rechargeable batteries designed specifically for use in electric rickshaws. They provide the necessary electrical power to run the motor and other electrical systems of the vehicle. E-Rickshaw batteries are typically lead-acid or lithium-ion batteries and come in various sizes and capacities to match the specific requirements of different e-rickshaw models. They must be able to perform in tough urban environments, have a long life span, and provide reliable power to ensure smooth and efficient operation of the vehicle.",
        image:   riksha,
        flag: "",
        link:"battery"
    },

    {
        name: "Tublar battery ",
        content: "Tubular batteries are a type of lead-acid battery with a longer life span, low maintenance, and high reliability. They have a tubular plate design for higher power output and are commonly used in solar power and backup power systems.",
        image:tube,
        flag: "left",
        link:"battery"
    },



   

]


export const invertor =
{
    title: " iCon 1100 ",
    tagline: "",
    desc: "Sunworth polycrystalline solar panels are Renewable Energy Test Station (RETS) and ISO9001:2008 international quality management system certified solar panels. Sunworth polycrystalline solar panels are manufactured with the state of art technology to meet peoples need for alternative power.",
    range: "Ranges Available: 10 Wp - 250 Wp",
    image: inverter,
    features: [
        "Pure Sine Wave technology",
        "Capacity - 900 VA, Rated Power - 756 W",
        " No Open wires as battery is encapsulated in the inverter asking it completely safe for children",

    ],

     extraFeatures: [
        {
            id: 0,
            img: one,
            text: "   Pure Sine Wave",
        },
        {
            id: 1,
            img: two,
            text: "  Hassel Free Water Top Up ",
        },
        {
            id: 2,
            img: three,
            text: "  Fast Battery Charging",
        },
        {
            id: 3,
            img: four,
            text: " Safe For Children  ",
        },
    ]

}



export const batteries =
{

    title: " Industrial Tubular Battery",
    disc: "Consistent players are the superior performers",
    desc: "Inverlast Tall tubular range of batteries are next generation Tall Tubular batteries which are designed to withstand long and frequent power cuts.",
    range: "Ranges available: 100Ah to 220AhRanges Available: 10 Wp - 250 Wp",
    image: battery,
    features: [
        "Extremely high purity, corrosion-resistant proprietary spine alloy composition ensures longer battery service life",
        "Tubular plate construction ensures uniform distribution of positive active material for extremely long life and superior performance",
        "Extra-strong, and flexible oxidation-resistant gauntlet for higher performance and extremely long life",
        "",
    ],

    extraFeatures: [
        {
            id: 0,
            img: one,
            text: "   Pure Sine Wave",
        },
        {
            id: 1,
            img: two,
            text: "  Hassel Free Water Top Up ",
        },
        {
            id: 2,
            img: three,
            text: "  Fast Battery Charging",
        },
        {
            id: 3,
            img: four,
            text: " Safe For Children  ",
        },
    ]
}



export const solarpannel =
{

    title: "Sunworth Poly PV Panels",
    disc: "",
    des: "Sunworth polycrystalline solar panels are Renewable Energy Test Station (RETS) and ISO9001:2008 international quality management system certified solar panels. Sunworth polycrystalline solar panels are manufactured with the state of art technology to meet peoples need for alternative power.",
    image: solar,
    range: "Ranges Available: 10 Wp - 250 Wp",
    features: [
        "High quality raw materials, advanced encapsulation.",
        "Positive tolerence.",
        "Excellent performance under weak light conditions",

    ],
    extraFeatures: [
        {
            id: 0,
            img: one,
            text: "   Pure Sine Wave",
        },
        {
            id: 1,
            img: two,
            text: "  Hassel Free Water Top Up ",
        },
        {
            id: 2,
            img: three,
            text: "  Fast Battery Charging",
        },
        {
            id: 3,
            img: four,
            text: " Safe For Children  ",
        },
    ]
}



{/*card data */ }


export const solarlist = [
    {
        image: solar,
        name: "Sunworth Poly PV Panels",
        price: "2000",
        val: "go"

    },
    {
        image: solar,
        name: "tv solar",
        price: "2000",
        val:"goo"
    },
]

export const inverterlist = [
    {
        image: inverter,
        name: "Icon 55",
        price: "3000",
        val: "go"



    },
    {
        image: inverter,
        name: "Inveter",
        price: "1000",
        val:"goo"


    },
]


export const batterylist = [
    {
        image: battery,
        name: "Torch battery",
        price: "1000",
        val:"go"


    },
    {
        image: battery,
        name: "Industrial Tubular Battery",
        price: "1000",
        val:"goo"


    },
]

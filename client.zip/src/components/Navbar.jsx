
import React, { useState, useEffect } from "react";

import { FiChevronDown } from 'react-icons/fi'
import { Link, NavLink } from 'react-router-dom'
import { GiHamburgerMenu } from 'react-icons/gi'
import { RxCross2 } from 'react-icons/rx'
import logo from '../images/gosolar.png'



const Navbar = () => {
  const [aboutCard, setAboutCard] = useState(false)
  const [courseCard, setCourseCard] = useState(false)
  const [open, setOpen] = useState(false)





  return (


    <section className='z-30 h-auto'>
      <div className='flex justify-between items-center px-8 pt-2 md:px-14 relative'>
        <div className=''>
          <Link to="/">
            <img src={logo} alt="logo"  className=" object-cover h-20 w-20"/> 
          
          </Link>
        </div>


        <div className='md:hidden'>
          {open ? <RxCross2 className='text-2xl' onClick={() => setOpen(false)} /> : <GiHamburgerMenu className='text-2xl' onClick={() => setOpen(true)} />}



        </div>
        <div className={`md:flex md:items-center  gap-14 font-bold text-gray-700 absolute z-50 md:z-auto md:[-1] md:static md:w-auto left-0 w-full bg-white px-8 py-2 md:px-0 md:py-0 border-2 md:border-0 md:bg-none transition-all duration-500 ease-in ${open ? 'top-100' : 'top-[-490px]'}`}>
          <div onMouseEnter={() => setAboutCard(true)} onMouseLeave={() => setAboutCard(false)} className="relative">
            <div className='flex items-center gap-2'>PRODUCT<FiChevronDown /></div>
            {/* Hover Card */}
            {aboutCard && <div className='md:absolute top-6 -left-10 z-10 w-[14rem] bg-white text-gray-800 p-4 border-t-2 0 shadow-md'>
              <div className='uppercase flex flex-col '>

                <NavLink to="/product/battery" className=' hover:underline underline-offset-1'>

                  <div id='so'>   <span onClick={() => setAboutCard(false)}> Batteries</span></div>
                </NavLink>
                <NavLink to="/product/solar" className=' hover:underline underline-offset-1'>
                  <span onClick={() => setAboutCard(false)}> Solar Pannel</span>
                </NavLink>
                <NavLink to="/product/inverter" className='hover:underline underline-offset-1'>
                  <span onClick={() => setAboutCard(false)}> Inverters</span>
                </NavLink>
              </div>
            </div>}
          </div>


          <div onMouseEnter={() => setCourseCard(true)} onMouseLeave={() => setCourseCard(false)} className="relative">
            <div className='flex items-center gap-2'>SUPPORT<FiChevronDown /></div>
            {/* Hover Card */}

            {courseCard && <div className='md:absolute top-6 -left-10 z-10 w-[14rem] bg-white text-gray-800 p-4 border-t-2  shadow-md'>
              <div className='uppercase '>
                <NavLink to="/support/HomeService" className=' w-full hover:underline underline-offset-1'>
                  <span onClick={() => setCourseCard(false)} className="text-sm">HOME SERVICE</span>
                </NavLink> <br />
                <NavLink to="/support/Inquiry" className='w-full hover:underline underline-offset-1'>
                  <span onClick={() => setCourseCard(false)} className=" text-sm">CUSTOMER INQUIERY</span>  <br />
                </NavLink>
                <NavLink to="/support/Feedback" className=' w-full hover:underline underline-offset-1'>
                  <span onClick={() => setCourseCard(false)} className="text-sm">FEEDBACK AND COMPLAIN</span>
                </NavLink>
              </div>
            </div>}
          </div>

          <div className='rounded-lg md:w-60 h-10 overflow-hidden'>
            <input type="search" placeholder='Search' className='bg-none h-full w-full pl-2 bg-slate-200' />
          </div>
        </div>
      </div>
    </section >

  )
}

export default Navbar



import React from 'react'

const List = ({ item }) => {
    return (

        <div className='m-10 hover: border border-gray-200 hover:shadow-md '>   
        <div className='gap-6  '>
        <div className='w-[15rem]  flex items-center justify-center  flex-col '>  
            <img src={item?.image} alt=""  className=' h-[10rem]   object-cover'/>
            <h1 className='flex justify-center text-[#393280] mt-4 font-Inter'>{item?.name}</h1>
            <div className='flex justify-center mt-2'>  
          <p className='flex justify-center items-center  text-[#ED553B]'> {item?.price}</p>
          </div>
            </div>
            
        </div>
        </div>
    )
}

export default List
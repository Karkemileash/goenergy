import React from 'react'
import { IoMdVideocam } from 'react-icons/io';
import luminious from '../images/luminious.jpg'


const Products = ({ item }) => {

    return (
        <section>

            <div className=' flex  md:flex flex-wrap  md:justify-center items-center gap-16 p-4'>
                <div className=' w-[20rem] md:w-[30rem] '>
                    <img src={item.image} alt="image" />
                </div>
                
                <div className='md:w-[28rem]'>
                    <h1 className='text-3xl font-bold'>{item.title} </h1>
                    <h3 className='text-xl font-sans font-semibold mt-1'>{item.tagline} </h3>
                    <p className=' text-gray-600 mt-4'>{item.desc}</p>
                    <h2 className=' text-[#2670B9] text-lg font-semibold mt-3'>{item.range}</h2>
                    <h1 className='  bg-slate-500 text-white p-2 w-[6rem] mt-3'> Features</h1>
                    <ul className='list-disc mt-2'>
                        {item.features.map((feature, index) => (
                            <li key={index}> {feature} </li>
                        ))}

                    </ul>
                    <div>

                   
             <a href='tel:980-1053774'> <button className=' md: bg-[#2670B9]  text-white  rounded-3xl px-4 py-2 mt-3'> Call Now </button>   </a> 
                    </div>



                </div>

                <div>
                
                </div>

            </div>

        </section>

    )
}

export default Products;
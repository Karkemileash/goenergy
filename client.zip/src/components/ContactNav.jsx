import React from 'react'
import { Link } from 'react-router-dom'
import {IoIosCall} from 'react-icons/io'
import {RiServiceFill} from 'react-icons/ri'

const ContactNav = () => {
    return (
        <div className=' hidden md:flex items-center justify-between bg-[#3281C3] text-white gap-3 px-4'>
            <nav className='flex  gap-3 text-sm p-3  '>
                <Link to="/"> HOME</Link>
                <Link to="/aboutus">ABOUT US</Link>
                <Link to="/contactus"> CONTACT US</Link>
              
                <Link to ="/corporate/client">CORPORATE CLIENTS</Link>
               
            </nav>
            <div className='flex gap-6'>
            <a href='tel:980-1053774'><span className='flex gap-2 items-center'> <IoIosCall size={25}/> SALES : 980-1053774  </span> </a>
             {/*   <span className='flex gap-2 items-center'> <RiServiceFill size={25}/> SERVICE : 98010881**</span> */}
            </div>

        </div>
    )
}

export default ContactNav;
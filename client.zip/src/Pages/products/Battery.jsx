import React from 'react'
import Hero from '../../components/Hero'
import Products from '../../components/Products'
import { batteries } from '../../components/AboutData'
import { batterylist } from '../../components/AboutData'
import List from '../../components/List'


const desc = 'Luminous world-class Home Ups Inverters offers high technology features and are specially designed to run sensitive and heavy load household appliances as well as industrial appliances. With the built in innovative and advance technology Luminous Home Ups helps users meet their power needs across all residential and commercial segments. Luminous Home Ups Inverters provides the users best Power Back Up Solutions and right value for money.17'

const Battery = () => {
  return (
    <section>
      <Hero title={"Battery"} desc={desc} />
      <div className='flex items-center  flex-wrap justify-center'>   
      {batterylist?.map((battery, index) =>{
        return(
           <a key={index} href='#go'>   
          <List key={index} item ={battery}/>
          </a>
        )
      })}
      </div>
      {/* <List item={batterylist} /> */}

      <div id='go'>
      <Products item={batteries} />

      </div>
     
      
    </section>

  )
}

export default Battery;
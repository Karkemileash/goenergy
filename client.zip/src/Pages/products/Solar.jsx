import React from "react";
import { solarpannel } from "../../components/AboutData";
import Hero from "../../components/Hero";
import Products from "../../components/Products";
import { solarlist } from "../../components/AboutData";
import List from "../../components/List";

const desc =
  "solar pannel  are specially designed to run sensitive and heavy load household appliances as well as industrial appliances. With the built in innovative and advance technology Luminous Home Ups helps users meet their power needs across all residential and commercial segments. Luminous Home Ups Inverters provides the users best Power Back Up Solutions and right value for money.17";

const Solar = () => {

  return (
    <div>
      <Hero title={"Solar Pannel"} desc={desc} />

      
      <div className="flex flex-wrap items-center justify-center">
        {solarlist?.map((solar, index) => {
          return (
           
           <a  key={index} href='#go'> 
               <List  item={solar} />
                  </a> 
          )
        })}
      </div>
     
      {/* <List item={solarlist} /> */}


      <div id="go"> 
      <Products item={solarpannel} />
      </div>
      
    </div>
  );
};

export default Solar;
import React from 'react'
import Hero from '../../components/Hero'
import Products from '../../components/Products'
import { invertor } from '../../components/AboutData'
import List from '../../components/List'
import { inverterlist } from '../../components/AboutData'

const desc = 'Luminous world-class Home Ups Inverters offers high technology features and are specially designed to run sensitive and heavy load household appliances as well as industrial appliances. With the built in innovative and advance technology Luminous Home Ups helps users meet their power needs across all residential and commercial segments. Luminous Home Ups Inverters provides the users best Power Back Up Solutions and right value for money.17'

const Inverter = () => {


  return (
    
<section>
      <Hero title={"inverter"} desc={desc} />
    
      <div className='flex  flex-wrap items-center justify-center'>   
      {inverterlist?.map((inverter, index) =>{
        return(
      <a href={`#${inverter.val}`}> 
      
          <List key={index} item ={inverter}/>
        
          </a>  ) })}
            </div>
     
      {/* <List item={inverterlist} /> */}
<div id='go'>
<Products item={invertor} />
</div>


<div id='goo'>
<Products item={invertor} />
</div>
   
      
    </section>
   
  )
}

export default Inverter;
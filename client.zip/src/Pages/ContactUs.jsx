import React, { useState } from 'react'
import contact from '../images/connectus.png'
import { FaHome } from 'react-icons/fa'
import { FiPhoneCall } from 'react-icons/fi'
import { ImLocation } from 'react-icons/im'
import { SlUserFollowing } from 'react-icons/sl'
import { BsFacebook, BsInstagram, BsTwitter, BsYoutube, BsLinkedin } from 'react-icons/bs'

const ContactUs = () => {
  const [map, setCurrentMap] = useState("map1");
  console.log(map)

  return (
    <div className='bg-[#F1F5F8]' >
      <div className='  flex items-center justify-center'>
        <img src={contact} className=" w-full h-[20rem]  md:w-[50%] md:h-[25rem] " />
      </div>
      <div className='flex flex-wrap gap-10 md:gap-24 justify-center px-20 mt-4 m-1 text-center p-7'>

        <div>

          <h1 className='font-bold text-center text-2xl'> Head office</h1>
          <h3 className='pt-2'>Naya Bato , Dhobighat, Lalitpur, Nepal</h3>

        </div>
        <div>

          <h1 className='font-bold text-center text-2xl'>Call directly</h1>
          <h3 className='pt-2'>980-1053774 Kathmandu Valley</h3>
      
    
        </div>

        <div>
          <h1 className='   font-bold text-center text-2xl'>Follow us</h1>  <br />
          <div className='flex gap-2   items-center justify-center'>
          <a href='https://www.facebook.com/goenergynepal/'>   <BsFacebook size={24} />  </a>
            <a href=''>  <BsInstagram size={24} /> </a>
   
            <a href=''>  < BsYoutube size={24} /> </a>
            <a href=''>  < BsLinkedin size={24} /> </a> 
          </div>
        </div>
      </div> 
      <h1 className=' font-bold text-2xl   text-center  mt-10'>  Custome Care</h1>
      <div className=' md:flex justify-center  py-10 w-50%  W-[40rem] md:w-full'>
   

       
            {map === "map1" && <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3533.252839602383!2d85.30118441506148!3d27.67857928280378!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb18377f7bb6ab%3A0x3489b97f0a2fab66!2sNaya%20Bato%2C%20Lalitpur%2044600!5e0!3m2!1sen!2snp!4v1675595396286!5m2!1sen!2snp" className="w-full md:w-[600px]" width="600" height="450" allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>}
        {/*{map === "map2" && <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d113060.50299444137!2d83.36249576257954!3d27.682045338460938!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3996864275d9755f%3A0x2b1e92d89d4bb3ae!2sButwal!5e0!3m2!1sen!2snp!4v1675247904933!5m2!1sen!2snp" className="w-full md:w-[600px]" width="600" height="450" allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>}
        {map === "map3" && <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d452506.4339391408!2d84.07741137146948!3d27.618119986194213!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3994439ad1ca5a8d%3A0x6c5e40f75e1f474f!2sChitawan!5e0!3m2!1sen!2snp!4v1675247935723!5m2!1sen!2snp" className="w-full md:w-[600px]" width="600" height="450" allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>}
  {map === "map4" && <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114311.3253137709!2d87.20176634384573!3d26.448349079488384!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ef744704331cc5%3A0x6d9a85e45c54b3fc!2sBiratnagar%2056613!5e0!3m2!1sen!2snp!4v1675247959715!5m2!1sen!2snp" className="w-full md:w-[600px]" width="600" height="450" allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>}  */}

        <div className='  md:bg-[#F1F5F8]'>
         {/* <button onClick={() => setCurrentMap("map1")} className="   bg-[#F1F5F8] w-full md:w-[10rem] p-3  active:bg-blue-700 text-black text-sm hover:bg-gray-200 "> Kathmandu</button> <br />
          
          <button onClick={() => setCurrentMap("map2")} className="   bg-[#F1F5F8] w-full md:w-[10rem] p-3  active:bg-blue-700 text-black text-sm hover:bg-slate-400 border-[1px]"> butwal</button> <br />
          <button onClick={() => setCurrentMap("map3")} className="   bg-[#F1F5F8] w-full md:w-[10rem] p-3  active:bg-blue-700 text-black text-sm hover:bg-slate-400 border-[1px]"> chitwan</button> <br />
  <button onClick={() => setCurrentMap("map4")} className="   bg-[#F1F5F8] w-full md:w-[10rem] p-3  active:bg-blue-700 text-black text-sm hover:bg-slate-400 border-[1px]"> biratnagar</button> <br /> 
*/}
  </div>
      </div>
    </div >

  )
}

export default ContactUs
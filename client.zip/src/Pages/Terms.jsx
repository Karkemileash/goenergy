import React from 'react'

const Terms = () => {
  return (
    <div>

        Coming soon
    </div>
  )
}

export default Terms
import React from 'react'

const Corporate = () => {
  return (
    <div>Corporate</div>
  )
}

export default Corporate
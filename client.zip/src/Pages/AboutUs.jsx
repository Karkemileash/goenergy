import React from 'react'
import about from '../images/about.jpg'
const AboutUs = () => {
    return (
        <div className=' flex-col md:items-center '>

            <img src={about} className=" w-[68rem] h-[20rem]    md:h-[30rem] md:w-full" />

            <div className=' md:flex gap-4 m-4'>
                <div className=' mt-5 text-center  w-full md:w-[50%]'>
                    <h1 className='font-bold text-3xl'> About Go Solar</h1>
                    <p className=' mt-7 '>  G.O Energy Pvt.Ltd. operates under the Golcha organization a multifaceted conglomerate with annual turnover of above Nrs 100 crores. G.O Energy Pvt.Ltd. is one of the leading and fastest growing trading companies that strongly believes in enhancing Nepal’s current energy sector scenario along with its sustainable growth.

                        The company was established in 2019 AD and is the sole distributor of OKaya Inverters, Batteries, Stabilizers and its accessories .The company offers a wide variety of alternative power backup solution products and has largest sales network across the whole country with around 200 plus  dealers and service centers in 7 major cities catering the full range service needs of our valued customer.</p>
                </div>
                <div className='mt-5  w-full md:w-[50%]'>
                    <h1 className='font-bold text-3xl'>  Our Technology Partner </h1>
                    <p className='mt-7'> OKAYA, the pioneer in the battery manufacturing industry, has been a symbol of trust and quality for years. Okaya is known for providing a wide range of batteries to meet the different energy requirements of the consumer. The varied product range of batteries is suitable for all kinds of applications, like Tubular Battery- Inverter Battery and Solar Battery, SMF Battery, E-Rickshaw Battery, Lithium and EV charging solutions.

                        Okaya is the sole manufacturer of 100% Tubular Batteries, which are considered as best for power backup needs, used both in Inverter and Solar Batteries.
                        .</p>

                    <h2 className='mt-3 font-bold'>  The batteries manufactured by Okaya are:</h2>
                    <li>Eco-friendly</li>
                    <li>  Reliable </li>
                    <li>  Long-Lasting </li>
                    <li>  Trusted for robust backups </li>

                </div>
            </div>
            <div className=' pt-20  '>
                <div className=' flex justify-center'>
                    <h1 className=' font-bold text-xl text-center bg-black text-white rounded-md  p-2 justify-center'>  Our values</h1>
                </div>

                <div className=' flex-row-reverse  md:flex gap-12 justify-center   px-14 py-10'>
                    <div className=' w-full md:w-[50%]'>
                        <h3 className='font-bold text-xl mt-'> System</h3>
                        <p className='leading-relaxed'> Be a system and process driven company that constantly invests in its physical
                            infrastructure, people, technology and all procedural
                            systems that drive efficiency and excellence</p>

                    </div>
                    <div className=' w-full md:w-[50%]'>
                        <h3 className='font-bold text-xl mt-4'> Integrity</h3>
                        <p className='leading-relaxed'>Maintain high ethical standards and compliance in conducting business</p>
                    </div>


                </div>

                <div className='   flex-row-reverse  md:flex gap-12 justify-center  pb-5 px-14 md:px-14 py-7 '>
                    <div className='   w-full md:w-[50%]'>
                        <h3 className='font-bold text-xl mt-4'>Learning</h3>
                        <p className='leading-relaxed'>Strongly emphasize the need to remain ahead of competition and be current with global standards and benchmarks in training employees</p>

                    </div>
                    <div className=' w-full md:w-[50%]'>
                        <h3 className='font-bold text-xl mt-4'> Unity</h3>
                        <p className='leading-relaxed'>Maintain and improve open communication platform, encourage team work, respect all and recognize excellence in performance</p>
                    </div>


                </div>


            </div>
        </div>



    )
}

export default AboutUs
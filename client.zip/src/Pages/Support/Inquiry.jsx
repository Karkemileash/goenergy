import React, { useState } from 'react';

import Hero from '../../components/Hero'
import Form from './Form';

const Inquiry = () => {
    return (
        <div>

            <Hero title={"Customer Inquiry"} desc={"We're here to help you with anything. Do not hesitate to write us."} />


            <div class=" bg-gray-100 flex items-center justify-center ">




                <div class="   py-4 md:py-8">
                    <div class="grid gap-4  text-sm grid-cols-1 lg:grid-cols-3  ">
                        <div class="text-gray-600">


                        </div>


                        <div class="grid gap-4 gap-y-2 text-sm grid-cols-1 md:grid-cols-5">
                            <div class="md:col-span-5">
                                <label for="full_name">Full Name</label>
                                <input type="text" name="full_name" id="full_name" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" />
                            </div>

                            <div class="md:col-span-5">
                                <label for="email">Email Address</label>
                                <input type="text" name="email" id="email" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="email@gmail.com" />
                            </div>

                            <div class="md:col-span-3">
                                <label for="address">Address / Street</label>
                                <input type="text" name="address" id="address" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="" />
                            </div>

                            <div class="md:col-span-2">
                                <label for="city">City</label>
                                <input type="text" name="city" id="city" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="" />
                            </div>

                            <div class="md:col-span-3">
                                <label for="address">Address / Street</label>
                                <input type="text" name="address" id="address" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="" />
                            </div>
                            <div class="md:col-span-2">
                                <label for="city">Phone no:</label>
                                <input type="text" name="city" id="city" class="h-10 border mt-1 rounded px-4 w-full bg-gray-50" value="" placeholder="" />
                            </div>

                            <div class="md:col-span-2">
                                <div class="md:col-span-2">

                                </div>
                            </div>
                            <div class="md:col-span-2">
                            </div>
                            <div class="md:col-span-1">

                            </div>
                            <div className=' justify-center'>
                                <label for="story">Feedback</label>

                                <textarea id="story" className='border mt-1 rounded px-4  border-gray-200'
                                    rows="5" cols="33">

                                </textarea>
                            </div>
                            <div class="md:col-span-2">

                            </div>

                            <div class="md:col-span-5 ">
                                <div class="inline-flex items-end">
                                    <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Submit</button>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>




            </div>


        </div>
    )
}

export default Inquiry